import React from 'react'

const Menu = () => {
  return (
    <div>
        <h1>아메리카노</h1>
        <p>3500</p>
    </div>

  )
}

export default Menu